#!/bin/bash -e

NVM=MAC-7000-v1.2.4-00-CS.nvm
MAC=
DAK=
MFT=
CFG=

cd "$(readlink -f $(dirname $0))"

function usage()
{
  echo "Usage:"
  echo "./qca7000-updatesh <config-profile> [mac-address]"
  echo
  echo " config-profile must be one of:"
  echo
  echo "  iot-generic    IoT generic, optimized for performance: 50561 off (SLAC off)"
  echo "  iot-conform    IoT over mains, optimized for conformity: 50561 on (SLAC off)"
  echo "  emob-charger   e-mobility use as charging station: SLAC in EVSE mode (50561 off)"
  echo "  emob-vehicle   e-mobility use as vehicle: SLAC in PEV mode (50561 off)"
  echo
  echo " mac-address is optional, if omitted, the first"
  echo " localy attached adapter will be programmed"
  exit -1  
}

if [ "$1" = "iot-conform" ] || 
   [ "$1" = "iot-generic" ] ||
   [ "$1" = "emob-charger" ] || 
   [ "$1" = "emob-vehicle" ]
then
  CFG="$1"
else
  usage
fi

MAC=$(./avreadpib $2 2>&1 | while read a b c; do if [ "$a $b" = "Saving as" ]; then echo ${c:1:12}; fi; done)

if [ "$MAC" = "" ]; then usage; fi

DAK=$(./avpibdump ${MAC}.pib 2>/dev/null | sed -n "s/^[ ]*0x0012 0x\([0-9A-F]*\) .*$/\1/p")

if [ "DAK" = "" ]
then
  echo "error: missing DAK in PIB, are you trying to program a remote device?"
  exit -1
fi

echo "CFG: $CFG"
echo "MAC: $MAC"
echo "DAK: $DAK"

MFT=$(./avpibdump ${MAC}.pib 2>/dev/null | sed -n "s/^[ ]*0x0024 \"\(.*\)\" 0x40 .*$/\1/p")

if [ "$MFT" != "devolo dLAN Green PHY Module [MT2489]" ]
then
  echo "error: $MAC is not a \"devolo dLAN Green PHY Module [MT2489]\", aborting"
  exit -1
fi

echo "MFT: $MFT"

(
  cat qca7000-config-profiles.txt
  echo "${MAC}_new.pib: ${CFG}; 0x0C 0x${MAC}; 0x12 0x${DAK}"
) | ./avmakepib - >/dev/null

./avwriteflash /dak:${DAK} ${MAC} ${MAC}_new.pib ${NVM} /wait

rm -f ${MAC}_new.pib ${MAC}.pib
